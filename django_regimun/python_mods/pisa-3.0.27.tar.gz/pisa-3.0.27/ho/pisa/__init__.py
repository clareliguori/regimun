# -*- coding: ISO-8859-1 -*-
#############################################
## (C)opyright by Dirk Holtwick, 2002-2007 ##
## All rights reserved                     ##
#############################################

"""
In the near future pisa will be moved into the namespace "ho"
This is a helper for migration
"""

__reversion__ = "$Revision: 160 $"
__author__    = "$Author: holtwick $"
__date__      = "$Date: 2008-03-12 16:40:03 +0100 (Mi, 12 Mrz 2008) $"

from sx.pisa3.pisa import *

__version__   = VERSION
