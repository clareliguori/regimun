#!/usr/local/bin/python
# -*- coding: ISO-8859-1 -*-
#############################################
## (C)opyright by Dirk Holtwick, 2002-2007 ##
## All rights reserved                     ##
#############################################

__version__ = "$Revision: 221 $"
__author__  = "$Author: holtwick $"
__date__    = "$Date: 2008-05-31 18:56:27 +0200 (Sa, 31 Mai 2008) $"
__svnid__   = "$Id: pisa.py 221 2008-05-31 16:56:27Z holtwick $"

import ho.pisa as pisa
pisa.command()
