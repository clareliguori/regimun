<?php 
include 'config.php'; 
?>

<html>
<head>
<title><?php echo $site_title; ?></title>

<link rel="stylesheet" type="text/css" charset="utf-8" media="all" href="<?php echo $css_location; ?>">
</head>
<body>

<div id="header">
<div id="logo"><a href="index.php" class="logolink"><img src="<?php echo $logo_location; ?>" alt="HAMUN Logo"></a></div>
<div id="pagename"><?php echo $conference_title; ?>: Secretariat Dashboard</div>
</div>
<div id="main-content">
