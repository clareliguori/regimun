<?php
include 'lib.php';

if(check_session()) {
  include 'header.php';

  // MAIN CONTENT

  include 'footer.php';
}

?>
