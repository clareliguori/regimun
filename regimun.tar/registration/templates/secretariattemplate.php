<?php 
include 'lib.php';

if(check_secretariat_session()) {
  include 'secretariatheader.php'; 

  // MAIN CONTENT

  include 'footer.php';
}
 ?>
