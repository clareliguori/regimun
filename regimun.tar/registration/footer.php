</div>

<div id="footer">
If you have any problems with this site, please report it to <a href="mailto: <?php echo $webmaster_email; ?>"><?php echo $webmaster_email; ?></a>.
</div>


</body>
</html>
